#ifndef __I2C_H
#define __I2C_H
#include "main.h"

extern I2C_HandleTypeDef    I2cHandle;
void I2C_Init(void);

#endif

