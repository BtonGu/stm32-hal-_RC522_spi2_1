#ifndef __TIM_H
#define __TIM_H
#include "main.h"


#define TIMx                           TIM3
#define TIMx_CLK_ENABLE()              __HAL_RCC_TIM3_CLK_ENABLE()

#define TIMx_IRQn                      TIM3_IRQn
#define TIMx_IRQHandler                TIM3_IRQHandler


void TIM_Init(void);

#endif

