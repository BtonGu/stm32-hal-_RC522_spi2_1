#ifndef __DHT11_H
#define __DHT11_H
#include "main.h"



uint8_t DHT11_Read_Data(uint8_t *th,uint8_t *dh);

#endif

