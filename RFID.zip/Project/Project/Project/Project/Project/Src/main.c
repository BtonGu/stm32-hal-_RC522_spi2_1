#include "main.h"
#include "gpio.h"//contain EXTI
#include "tim.h"
#include "dht11.h"
#include "lcd.h"
#include "adc.h"
#include "i2c.h"
#include "rc522.h"
void SystemClock_Config(void);
void Error_Handler(void);


int main(void)
{
	uint8_t th,dh;
	uint8_t eeprom;
  /* STM32F103xG HAL library initialization:
  ��RC522����Ϊ�Լ���ֲ
	�ص㣺ֻ��һ����ʼ�������ɵ�һ��
				IOд����ͬ
	      SPI2_ReadWriteByteд����ͬ
	      �����ѵ���SPI���֣�����С��չ
	      1��SPI_POLARITY_LOW&SPI_PHASE_1EDGE
	      2�����룺SPI_POLARITY_HIGH&SPI_PHASE_2EDGE������ÿ��и߼��ԣ��ڶ��������أ���
	      3��ֻ�޸�һ���أ�
	      �Ļ�ȥ������
     */
  HAL_Init();

  /* Configure the system clock to 72 MHz */
  SystemClock_Config();
	GPIO_Init();
	EXIT_Init();
	Usart_Init();
	//LCD_Init();
	SPI2_Init();  
	TIM_Init();
	ADC1_Init();
	I2C_Init();
	
  
	

  /* Output a message on Hyperterminal using printf function */
  printf("\n\r UART Printf Example: retarget the C library printf function to the UART\n\r");
  printf("** Test finished successfully. ** \n\r");
	LCD_ShowString( 30, 40, 200,16,16, "GGG");		//��ʾһ���ַ���,12/16����

  //GPIOE->CRL &=~ (0x0F00000);
	//GPIOE->CRL |=  (0x0100000);
	//GPIOE->ODR |=(1<<5);
  /* Infinite loop */
  while (1)
  {
//		DHT11_Read_Data(&th,&dh);
//		//if(DHT11_Read_Data(&th,&dh)==1)printf("temp_error\r\n");
//		printf("temp=%2d,dh=%2d",th,dh);
//		printf("�¶�ʪ��\r\n");
//		
//		HAL_ADC_Start(&hadc1);
//		HAL_ADC_PollForConversion(&hadc1,100);
//		HAL_ADC_GetValue(&hadc1);
//		printf("ADC=%2d\r\n",HAL_ADC_GetValue(&hadc1));
//		
//		HAL_Delay(10);
//		if(HAL_I2C_Mem_Read(&I2cHandle,0xA1,0x01,I2C_MEMADD_SIZE_8BIT,&eeprom,1,100)==HAL_ERROR)printf("I2C_Error\r\n");
//		HAL_Delay(10);printf("24c02=%2d\r\n",eeprom);
//		
//		printf("GPIOB->CRL=%4d",(GPIOB->CRL)>>(6*4));
//		
		ReaderCard();
		printf("\r\n");
		HAL_Delay(800);
  }
}




/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow : 
  *            System Clock source            = PLL (HSE)
  *            SYSCLK(Hz)                     = 72000000
  *            HCLK(Hz)                       = 72000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 2
  *            APB2 Prescaler                 = 1
  *            HSE Frequency(Hz)              = 8000000
  *            HSE PREDIV1                    = 1
  *            PLLMUL                         = 9
  *            Flash Latency(WS)              = 2
  * @param  None
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef clkinitstruct = {0};
  RCC_OscInitTypeDef oscinitstruct = {0};
  
  /* Enable HSE Oscillator and activate PLL with HSE as source */
  oscinitstruct.OscillatorType  = RCC_OSCILLATORTYPE_HSE;
  oscinitstruct.HSEState        = RCC_HSE_ON;
  oscinitstruct.HSEPredivValue  = RCC_HSE_PREDIV_DIV1;
  oscinitstruct.PLL.PLLState    = RCC_PLL_ON;
  oscinitstruct.PLL.PLLSource   = RCC_PLLSOURCE_HSE;
  oscinitstruct.PLL.PLLMUL      = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&oscinitstruct)!= HAL_OK)
  {
    /* Initialization Error */
    while(1);
  }

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 
     clocks dividers */
  clkinitstruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  clkinitstruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  clkinitstruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  clkinitstruct.APB2CLKDivider = RCC_HCLK_DIV1;
  clkinitstruct.APB1CLKDivider = RCC_HCLK_DIV2;  
  if (HAL_RCC_ClockConfig(&clkinitstruct, FLASH_LATENCY_2)!= HAL_OK)
  {
    while(1);
  }
}

  void Error_Handler(void)
{
	printf("error");
}

void delay_us(uint16_t us)
{
  uint32_t startval,tickn,delays,wait;
 
  startval = SysTick->VAL;
  tickn = HAL_GetTick();//sysc = 72000;  //SystemCoreClock / (1000U / uwTickFreq);
  delays =us * 72; //sysc / 1000 * udelay;
  if(delays > startval)
    {
      while(HAL_GetTick() == tickn);
      wait = 72000 + startval - delays;
      while(wait < SysTick->VAL);
    }
  else
    {
      wait = startval - delays;
      while(wait < SysTick->VAL && HAL_GetTick() == tickn);
    }
}
	




/******************END OF FILE****/
