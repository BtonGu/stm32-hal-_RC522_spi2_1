#ifndef __ADC_H
#define __ADC_H
#include "main.h"



extern ADC_HandleTypeDef    hadc1;
void ADC1_Init(void);

#endif

